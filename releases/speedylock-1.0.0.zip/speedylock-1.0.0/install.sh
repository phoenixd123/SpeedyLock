#!/bin/sh
# SpeedyLock installer. Pass any speedy command: ./install.sh plan, ./install.sh uninstall
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$HERE/install.py" "$@"
fi
exec python "$HERE/install.py" "$@"
