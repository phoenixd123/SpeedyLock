@echo off
rem SpeedyLock installer. Writes the config, then opens doctor's report.
setlocal
set "HERE=%~dp0"
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 "%HERE%install.py" %*
  set "RC=%ERRORLEVEL%"
  goto done
)
where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python "%HERE%install.py" %*
  set "RC=%ERRORLEVEL%"
  goto done
)
echo SpeedyLock needs Python 3.8 or newer.
echo Install it from https://www.python.org/downloads/ and tick
echo "Add python.exe to PATH" during setup, then run this file again.
set "RC=1"

:done
echo.
pause
exit /b %RC%
