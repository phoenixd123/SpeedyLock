@echo off
rem Removes the SpeedyLock block and restores the backups.
setlocal
call "%~dp0install.bat" uninstall
