# SpeedyLock 1.0.0 — install guide

SpeedyLock writes three things: a marked block of convars in
`game/citadel/cfg/autoexec.cfg`, quality keys merged into `video.txt`, and a few
convars merged into the existing `ConVars` block of `gameinfo.gi`. It never
replaces a file, never touches resolution, monitor, gamma or `deviceid`, and
backs everything up first.

This folder is the **1.0 release bundle**. It carries the config files a mod
manager can read plus the installer that does the actual writing.

| File | For |
| --- | --- |
| `install.bat` / `install.sh` | one-step install; backs up, merges, prints the report |
| `uninstall.bat` | removes the block and restores the backups |
| `autoexec.cfg` | the commands, plain — for Grimoire's Autoexec manager |
| `convars-block.txt` | every convar the install applies, as a `ConVars` block |
| `mod-interchange.json` | DMM "Open export file…" / Grimoire "Import from file…" |
| `speedy.py`, `speedylock/` | the tool itself, so the installer works offline |
| `release-manifest.json` | SHA-256 of every file here |

Profile **balanced**, fps cap **uncapped (0)**, relief **off**.

## 30 seconds: the installer

Windows: double-click `install.bat`. macOS/Linux/Proton: `./install.sh`.

```bash
./install.sh plan      # what would be written, nothing touched
./install.sh           # write it
./install.sh doctor    # audit all three files
./install.sh uninstall # put everything back
```

Drop `--game-dir "…/steamapps/common/Deadlock"` on the end if detection fails.

## Grimoire

Grimoire installs only `.vpk` files and has a separate **Autoexec manager** for
console commands that run at launch. Open `autoexec.cfg` from this folder, copy
it, paste it into the Autoexec manager. Do not let it replace a file you already
use — SpeedyLock writes a marked block and merges, but a manual paste does not.

If you want the visual keys in `video.txt` as well, that part is not something a
manager does; run `install.sh` once and let SpeedyLock handle all three files.

## Deadlock Mod Manager

Two routes, both under **Mods Library**:

1. **Import config** — drop `speedylock-1.0.0.zip`, `autoexec.cfg` or
   `convars-block.txt` into it. DMM shows what will apply and what will not
   before writing, and does not copy a mod's `gameinfo.gi` over yours. This is
   the route that matches what SpeedyLock is: config, not assets.
2. **Open export file…** — pick `mod-interchange.json`. The commands ride in
   `profiles[].autoexec`, which is where DMM keeps console commands that run at
   launch. `mods[]` is empty on purpose; see below.

## Why there is no .vpk

A `.vpk` is the only thing both managers will *install* as a mod, and it is the
one thing this project will not fake. Whether the engine resolves `cfg/` through
the addon search path is not documented anywhere, so a VPK containing
`autoexec.cfg` would install cleanly, appear in your library, and very possibly
change nothing at all — or fight the `gameinfo.gi` that the manager rewrites on
every launch. An inert download with a green tick is worse than an honest
config tool.

## What gets written, and how to undo it

```
autoexec.cfg   a marked block; your own commands outside it are untouched
video.txt      quality keys merged in place; display keys are refused
gameinfo.gi    convars merged before the existing ConVars closing brace
```

`uninstall` restores each file from the first backup SpeedyLock ever took, which
is the state before it touched anything. `doctor` re-checks all three files and
says which profile is installed — that key pastes straight back into `install`.

Full documentation, the convar knowledge base and the honest limitations are in
`DOCUMENTATION.md`. Licensing and attribution: `LICENSE.md`, `CREDITS.md`.
