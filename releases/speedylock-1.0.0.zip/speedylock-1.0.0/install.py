#!/usr/bin/env python3
"""One-file installer shipped inside the SpeedyLock release bundle.

Run it with no arguments to install, or pass any ``speedy`` command through:
``install.py plan``, ``install.py doctor``, ``install.py uninstall``.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from speedylock.cli import main  # noqa: E402

DEFAULT = ["install", "--profile", 'balanced', "--fps-cap", 0]

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:] or DEFAULT))
